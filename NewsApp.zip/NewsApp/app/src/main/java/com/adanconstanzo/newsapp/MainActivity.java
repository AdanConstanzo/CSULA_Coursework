package com.adanconstanzo.newsapp;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements NewsAdapter.ListItemClickListener{

    private ArrayList<NewsItem> mNewsItems;
    private EditText mSearchBoxEditText;
    private NewsAdapter mAdapter;
    private RecyclerView mNumbersList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.mNewsItems = new ArrayList<NewsItem>();

        mSearchBoxEditText = findViewById(R.id.et_search_box);


        mNumbersList = findViewById(R.id.news_articles);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mNumbersList.setLayoutManager(layoutManager);

        mNumbersList.setHasFixedSize(true);

        mAdapter = new NewsAdapter(this.mNewsItems, this);

        mNumbersList.setAdapter(mAdapter);

        mSearchBoxEditText.setText("the-next-web");
        makeNewsSearch("the-next-web");
    }

    private void makeNewsSearch(String newsQuery) {
        mNewsItems.clear();
        URL newsSearchUrl = NetworkUtils.SearchArticle(newsQuery);
        new NewsQueryTask().execute(newsSearchUrl);
    }

    @Override
    public void onListItemClick(int clickedItemIndex) {

        String url = mNewsItems.get(clickedItemIndex).url;
        // Define a new intent to browse the url of the specific item
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        // Start the intent
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int itemThatWasClickedId = item.getItemId();
        if (itemThatWasClickedId == R.id.action_search) {
            Toast.makeText(MainActivity.this, mSearchBoxEditText.getText() , Toast.LENGTH_SHORT).show();
            makeNewsSearch(mSearchBoxEditText.getText().toString());
            return true;
        }
        return super.onOptionsItemSelected(item);

    }

    public class NewsQueryTask extends AsyncTask<URL, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(URL... params) {
            URL searchUrl = params[0];
            String newsSearchResults = null;
            try {
                newsSearchResults = NetworkUtils.getResponseFromHttpUrl(searchUrl);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return newsSearchResults;
        }

        @Override
        protected void onPostExecute(String githubSearchResults) {

            if (githubSearchResults != null && !githubSearchResults.equals("")) {
                try {
                    mNewsItems.addAll(NetworkUtils.responseToNewsItems(githubSearchResults));
                    mAdapter.notifyDataSetChanged();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                //showErrorMessage();
            }
        }
    }
}
