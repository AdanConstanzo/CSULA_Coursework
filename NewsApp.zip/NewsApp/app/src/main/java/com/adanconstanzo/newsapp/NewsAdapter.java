package com.adanconstanzo.newsapp;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View.OnClickListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;



public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {


    private ArrayList<NewsItem> mNewsItems;

    // our interface memeber variable
    final private ListItemClickListener mOnClickListener;

    // constructor
    public NewsAdapter(ArrayList<NewsItem> items, ListItemClickListener listener) {
        this.mNewsItems = items;
        this.mOnClickListener = listener;

    }

    // interface we have to implement in main activity.
    // this is how we handle clicks for recycler.
    public interface ListItemClickListener {
        void onListItemClick(int clickedItemIndex);
    }


    @Override
    public int getItemCount() {
        return this.mNewsItems.size();
    }

    // Holder create implementation
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, final int viewType) {
        Context context = viewGroup.getContext();
        int layoutIdForListItem = R.layout.news_list_item;
        LayoutInflater inflater = LayoutInflater.from(context);
        boolean shouldAttachToParentImmediately = false;

        View view = inflater.inflate(layoutIdForListItem, viewGroup, shouldAttachToParentImmediately);
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        NewsItem currentNewsItem = mNewsItems.get(position);

        holder.title.setText(currentNewsItem.title);
        holder.description.setText(currentNewsItem.description);
        holder.time.setText(currentNewsItem.publishedAt);

        new DownloadImageTask(holder.image) .execute(currentNewsItem.urlToImage);


    }

    //
    class ViewHolder extends RecyclerView.ViewHolder
            implements OnClickListener {
        private TextView title;
        private TextView description;
        private TextView time;
        private ImageView image;

        public ViewHolder(View itemView) {
            // Stores the itemView in a public final member variable that can be used
            // to access the context from any ViewHolder instance
            super(itemView);
            // populating our holder to content of the layout.
            title =  itemView.findViewById(R.id.news_article_title);
            description = itemView.findViewById(R.id.news_article_description);
            time = itemView.findViewById(R.id.news_article_time);
            image = itemView.findViewById(R.id.news_article_image);
            // sets the on click listener for item.
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            int clickedPosition = getAdapterPosition();
            System.out.println(clickedPosition);
            mOnClickListener.onListItemClick(clickedPosition);
        }


    }

    // Separate class to download images with an async task.
    // preventing blockage of UI Thread.
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;
        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }
}
