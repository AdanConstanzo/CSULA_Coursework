# CS_4540_HW_1
This is Homework 1 for Android Class CS 4540. 
This git includes part 1 and part 2 of the homework and it also contains all the 3 testing files which all passed.
