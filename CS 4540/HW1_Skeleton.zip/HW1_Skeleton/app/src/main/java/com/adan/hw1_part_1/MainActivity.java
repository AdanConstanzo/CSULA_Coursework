package com.adan.hw1_part_1;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;


import com.example.rkjc.news_app_2.R;

import java.io.IOException;
import java.net.URL;


public class MainActivity extends AppCompatActivity {

    private TextView mUrlDisplayTextView;
    private TextView mSearchResultsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hw1_part_2);


        mUrlDisplayTextView = (TextView) findViewById(R.id.tv_url_display);
        mSearchResultsTextView = (TextView) findViewById(R.id.tv_github_search_results_json);
    }


    private void makeNewsSearch() {
        String search = "the-next-web";
        mUrlDisplayTextView.setText(search);
        URL newsSearchUrl = NetworkUtils.SearchArticle(search);
        new NewsQueryTask().execute(newsSearchUrl);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemThatWasClickedId = item.getItemId();
        if (itemThatWasClickedId == R.id.action_search) {
            makeNewsSearch();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public class NewsQueryTask extends AsyncTask<URL, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(URL... params) {
            URL searchUrl = params[0];
            String newsSearchResults = null;
            try {
                newsSearchResults = NetworkUtils.getResponseFromHttpUrl(searchUrl);
                System.out.print(newsSearchResults);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return newsSearchResults;
        }

        @Override
        protected void onPostExecute(String githubSearchResults) {

            if (githubSearchResults != null && !githubSearchResults.equals("")) {

                mSearchResultsTextView.setText(githubSearchResults);

            } else {
                //showErrorMessage();
            }
        }
    }

}
