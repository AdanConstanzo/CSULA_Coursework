package com.adan.hw1_part_2;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class JsonUtils {

    public  static ArrayList<NewsItem> parseNews(String response) {
        ArrayList<NewsItem> list = new ArrayList<NewsItem>();
        try {
            JSONObject obj = new JSONObject(response);
            JSONArray array = obj.getJSONArray("articles");
            //NewsItem(String author, String title, String description, String url, String urlToImage, String publishedAt)
            for(int i = 0; i < array.length(); i++) {
                list.add(new NewsItem(array.getJSONObject(i).getString("author"),
                        array.getJSONObject(i).getString("title"),
                        array.getJSONObject(i).getString("description"),
                        array.getJSONObject(i).getString("url"),
                        array.getJSONObject(i).getString("urlToImage"),
                        array.getJSONObject(i).getString("publishedAt")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}


